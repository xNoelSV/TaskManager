package com.xnoelsv.taskservice.domain;

public enum EStatus {
    TODO,
    IN_PROGRESS,
    DONE,
    CANCELLED
}
